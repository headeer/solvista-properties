// Initialize when DOM is loaded
document.addEventListener("DOMContentLoaded", function () {
  // Check if the map container exists before initializing
  const mapContainer = document.getElementById("map");
  if (!mapContainer) {
    console.error(
      "Map container not found. Make sure the page has a div with id='map'"
    );
    return;
  }

  // Initialize the map and property filters only once
  if (!window.searchByMap) {
    window.searchByMap = new SearchByMap();
  }
  if (!window.propertyFilters) {
    window.propertyFilters = new PropertyFilters(window.searchByMap);
  }
});

// SearchByMap class for handling map functionality
class SearchByMap {
  constructor() {
    this.map = null;
    this.markers = [];
    this.markerClusterGroup = null;
    this.loadedPropertyIds = new Set();
    this.currentBounds = null;
    this.isLoadingProperties = false;
    this.allPropertiesLoaded = false;
    this.currentPage = 1;
    this.totalPropertiesCount = 0;
    this.apiConfig = {
      clientId: "1033180",
      apiKey: "3728f0e4d6f477572c542f41a7154b4cc0e2be8b",
      agencyFilterId: "1", // Default filter for sales
    };

    // Initialize map only once
    this.initMap();
    this.setupMapEventListeners();
    this.loadProperties();
  }

  initMap() {
    const mapContainer = document.getElementById("map");
    if (!mapContainer) {
      console.error("Map container not found");
      return;
    }

    // Check if map is already initialized
    if (this.map) {
      return;
    }

    try {
      // Initialize the map centered on Marbella
      this.map = L.map("map", {
        center: [36.516666, -4.883333],
        zoom: 12,
        minZoom: 5,
        maxZoom: 18,
      });

      // Add the OpenStreetMap tile layer
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(this.map);

      // function fetchProperties() {
      //   const agencyFilter = 5;
      //   const p2Value = '3728f0e4d6f477572c542f41a7154b4cc0e2be8b';
        
      //   fetch(`https://webapi.resales-online.com/V6/SearchProperties?p_agency_filterid=${agencyFilter}&p1=1033180&p2=${p2Value}`)
      //   .then((response) => response.json())
      //   .then((data) => {
      //     console.log("Properties:", data);
          
      //       let maxItems = 10;
      //       data.Property.forEach((property, index) => {
      //         //TODO for tests
      //         if (index <= maxItems) {
      //           fetch(
      //             `https://webapi.resales-online.com/V6/PropertyDetails?p_agency_filterid=${agencyFilter}&p1=1033180&p2=${p2Value}&P_RefId=${property.Reference}&P_ShowGPSCoords=TRUE`
      //           )
      //             .then((propertyDetails) => {
      //               var marker = L.marker([
      //                 propertyDetails.GpsX,
      //                 propertyDetails.GpsY,
      //               ]).addTo(map);
      //               marker.bindPopup(`Price: ${propertyDetails.Price} €`);
      //             });
      //         }
      //       });
      //     })
      //     .catch((error) => console.error("Error during data fetch:", error));
      // }

      // fetchProperties();

      // map.on("moveend", fetchProperties);

      // Initialize marker cluster group
      this.markerClusterGroup = L.markerClusterGroup({
        maxClusterRadius: 50,
        spiderfyOnMaxZoom: true,
        showCoverageOnHover: false,
        zoomToBoundsOnClick: true,
      });
      this.map.addLayer(this.markerClusterGroup);
    } catch (error) {
      console.error("Error initializing map:", error);
    }
  }

  setupMapEventListeners() {
    if (!this.map) return;

    // Listen for map movement events
    this.map.on("moveend", () => {
      if (this.hasSignificantChange()) {
        this.loadProperties();
      }
    });

    // Listen for zoom events
    this.map.on("zoomend", () => {
      if (this.hasSignificantChange()) {
        this.loadProperties();
      }
    });
  }

  hasSignificantChange() {
    if (!this.map || this.isLoadingProperties) return false;

    const newBounds = this.map.getBounds();
    const newCenter = this.map.getCenter();
    const newZoom = this.map.getZoom();

    // If this is the first load or no previous bounds
    if (!this.currentBounds) {
      this.currentBounds = newBounds;
      return true;
    }

    // Check if center has moved significantly (more than 20% of the view)
    const centerLatLng = L.latLng(newCenter.lat, newCenter.lng);
    const oldCenterLatLng = L.latLng(
      this.map.getCenter().lat,
      this.map.getCenter().lng
    );
    const distance = centerLatLng.distanceTo(oldCenterLatLng);
    const viewSize = this.map.getSize();
    const significantDistance = Math.min(viewSize.x, viewSize.y) * 0.2;

    // Check if zoom level has changed
    const zoomChanged = newZoom !== this.map.getZoom();

    // Update current bounds
    this.currentBounds = newBounds;

    return distance > significantDistance || zoomChanged;
  }

  async loadProperties() {
    if (this.isLoadingProperties || this.allPropertiesLoaded) return;

    this.isLoadingProperties = true;
    const bounds = this.map.getBounds();

    try {
      await this.loadPropertiesForBounds(bounds);
    } catch (error) {
      console.error("Error loading properties:", error);
      // Fallback to dummy data if API fails
      this.updateMapMarkers(this.getDummyProperties());
    } finally {
      this.isLoadingProperties = false;
    }
  }

  async loadPropertiesForBounds(bounds) {
    // Use WordPress AJAX endpoint instead of direct API call to avoid CORS issues
    const formData = new FormData();
    formData.append("action", "property_search");
    formData.append("nonce", solvistaPropertySearch.nonce);
    formData.append("page", this.currentPage);
    formData.append(
      "bounds",
      JSON.stringify({
        south: bounds.getSouth(),
        north: bounds.getNorth(),
        west: bounds.getWest(),
        east: bounds.getEast(),
      })
    );

    // Add any active filters
    if (window.propertyFilters && window.propertyFilters.filters) {
      formData.append(
        "filters",
        JSON.stringify(window.propertyFilters.filters)
      );
    }

    try {
      console.log("Sending AJAX request to:", solvistaPropertySearch.ajaxurl);
      const response = await fetch(solvistaPropertySearch.ajaxurl, {
        method: "POST",
        body: formData,
        credentials: "same-origin",
      });

      if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}`);
      }

      const data = await response.json();
      console.log("API response:", data);

      if (!data.success) {
        throw new Error(data.data || "API request failed");
      }

      const properties = data.data.properties || [];

      if (properties.length === 0) {
        this.allPropertiesLoaded = true;
        return;
      }

      // Update total properties count
      this.totalPropertiesCount = data.data.total || properties.length;
      this.updatePropertyCount();

      // Filter out already loaded properties
      const newProperties = properties.filter(
        (property) => !this.loadedPropertyIds.has(property.id)
      );

      if (newProperties.length > 0) {
        this.updateMapMarkers(newProperties);

        // Add new property IDs to the set
        newProperties.forEach((property) =>
          this.loadedPropertyIds.add(property.id)
        );

        // Increment page for next load
        this.currentPage++;
      } else {
        this.allPropertiesLoaded = true;
      }
    } catch (error) {
      console.error("Error fetching properties:", error);
      // Fallback to dummy data if API fails
      this.updateMapMarkers(this.getDummyProperties());
    }
  }

  updateMapMarkers(properties) {
    if (!this.map || !this.markerClusterGroup) return;

    // Clear existing markers if this is the first load
    if (this.markers.length === 0) {
      this.markerClusterGroup.clearLayers();
    }

    const bounds = L.latLngBounds();

    properties.forEach((property) => {
      if (!property.latitude || !property.longitude) return;

      const marker = L.marker([property.latitude, property.longitude], {
        title: property.title,
      });

      const popupContent = this.createPropertyPopup(property);
      marker.bindPopup(popupContent);

      marker.on("click", () => {
        this.highlightProperty(property.id);
      });

      this.markerClusterGroup.addLayer(marker);
      this.markers.push(marker);
      bounds.extend([property.latitude, property.longitude]);
    });

    // Fit map to show all markers on first load
    if (this.markers.length === properties.length) {
      this.map.fitBounds(bounds, { padding: [50, 50] });
    }
  }

  createPropertyPopup(property) {
    // Ensure price is a number before using toLocaleString
    const price =
      typeof property.price === "number"
        ? property.price
        : parseFloat(property.price) || 0;

    return `
      <div class="property-marker">
        <h3>${property.title || "Property"}</h3>
        <p>${property.location || "Location not specified"}</p>
        <p>€${price.toLocaleString()}</p>
        <p>${property.bedrooms || 0} beds • ${property.bathrooms || 0} baths</p>
        <a href="${property.url || "#"}" target="_blank">View Property</a>
      </div>
    `;
  }

  highlightProperty(propertyId) {
    // Remove highlight from all markers
    this.markers.forEach((marker) => {
      marker.setIcon(L.Icon.Default);
    });

    // Find and highlight the selected property marker
    const marker = this.markers.find((marker) => {
      const popup = marker.getPopup();
      return popup && popup.getContent().includes(propertyId);
    });

    if (marker) {
      marker.setIcon(L.Icon.Red);
      marker.openPopup();
      this.map.setView(marker.getLatLng(), this.map.getZoom());
    }
  }

  updatePropertyCount() {
    const countElement = document.querySelector(".listings-count");
    if (countElement) {
      countElement.textContent = `${this.totalPropertiesCount} properties found`;
    }
  }

  resetPropertyLoading() {
    this.loadedPropertyIds.clear();
    this.currentBounds = null;
    this.isLoadingProperties = false;
    this.allPropertiesLoaded = false;
    this.currentPage = 1;
    this.markers = [];
    this.markerClusterGroup.clearLayers();
  }

  getDummyProperties() {
    return [
      {
        id: "1",
        title: "Luxury Villa in Marbella",
        location: "Marbella, Costa del Sol",
        price: 2500000,
        bedrooms: 5,
        bathrooms: 4,
        latitude: 36.5097,
        longitude: -4.886,
        url: "#",
      },
      {
        id: "2",
        title: "Modern Apartment in Puerto Banús",
        location: "Puerto Banús, Marbella",
        price: 750000,
        bedrooms: 3,
        bathrooms: 2,
        latitude: 36.4858,
        longitude: -4.9556,
        url: "#",
      },
      {
        id: "3",
        title: "Beachfront Penthouse",
        location: "Estepona, Costa del Sol",
        price: 1200000,
        bedrooms: 4,
        bathrooms: 3,
        latitude: 36.4276,
        longitude: -5.1459,
        url: "#",
      },
    ];
  }
}

// PropertyFilters class for handling property filtering
class PropertyFilters {
  constructor(searchByMap) {
    this.searchByMap = searchByMap;
    this.filters = {};
    this.init();
  }

  init() {
    this.setupFilterListeners();
    this.setupQuickFilters();
  }

  setupFilterListeners() {
    // Reset filters button
    const resetButton = document.getElementById("reset-filters");
    if (resetButton) {
      resetButton.addEventListener("click", () => this.resetFilters());
    }

    // Apply filters button
    const applyButton = document.getElementById("apply-filters");
    if (applyButton) {
      applyButton.addEventListener("click", () => this.applyFilters());
    }

    // Individual filter inputs
    const filterInputs = document.querySelectorAll(
      ".filter-group select, .filter-group input"
    );
    filterInputs.forEach((input) => {
      input.addEventListener("change", () => {
        this.updateFilterValue(input);
      });
    });
  }

  setupQuickFilters() {
    const quickFilterButtons = document.querySelectorAll(
      ".quick-selection button"
    );
    quickFilterButtons.forEach((button) => {
      button.addEventListener("click", () => {
        button.classList.toggle("active");
        this.updateQuickFilter(button.dataset.filter);
      });
    });
  }

  updateFilterValue(input) {
    const filterName = input.name;
    const filterValue = input.value;

    if (filterValue) {
      this.filters[filterName] = filterValue;
    } else {
      delete this.filters[filterName];
    }
  }

  updateQuickFilter(filterName) {
    const button = document.querySelector(
      `.quick-selection button[data-filter="${filterName}"]`
    );
    const isActive = button.classList.contains("active");

    if (isActive) {
      this.filters[filterName] = "yes";
    } else {
      delete this.filters[filterName];
    }
  }

  resetFilters() {
    // Reset all filter inputs
    const filterInputs = document.querySelectorAll(
      ".filter-group select, .filter-group input"
    );
    filterInputs.forEach((input) => {
      input.value = "";
    });

    // Reset quick filter buttons
    const quickFilterButtons = document.querySelectorAll(
      ".quick-selection button"
    );
    quickFilterButtons.forEach((button) => {
      button.classList.remove("active");
    });

    // Clear filters object
    this.filters = {};

    // Reset map and reload properties
    this.searchByMap.resetPropertyLoading();
    this.searchByMap.loadProperties();
  }

  applyFilters() {
    // Reset map and reload properties with new filters
    this.searchByMap.resetPropertyLoading();
    this.searchByMap.loadProperties();
  }
}

// Make searchByMap instance available globally
window.searchByMap = null;
window.propertyFilters = null;
